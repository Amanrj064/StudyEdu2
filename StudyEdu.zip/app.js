const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = "admin123";

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

const upload = multer({ dest: "public/uploads/" });

let data = [];
const dataPath = "./data.json";
if (fs.existsSync(dataPath)) {
  data = JSON.parse(fs.readFileSync(dataPath));
}

app.get("/", (req, res) => {
  res.render("index", { data });
});

app.get("/admin", (req, res) => {
  res.render("login", { error: null });
});

app.post("/admin", (req, res) => {
  const { password } = req.body;
  if (password === ADMIN_PASSWORD) {
    res.render("admin", { message: null });
  } else {
    res.render("login", { error: "Invalid password!" });
  }
});

app.post("/upload", upload.single("file"), (req, res) => {
  const { category } = req.body;
  if (!req.file) {
    return res.render("admin", { message: "No file uploaded!" });
  }
  const fileInfo = {
    filename: req.file.filename,
    originalname: req.file.originalname,
    category,
    mimetype: req.file.mimetype
  };
  data.push(fileInfo);
  fs.writeFileSync(dataPath, JSON.stringify(data));
  res.render("admin", { message: "Upload successful!" });
});

app.listen(PORT, () => {
  console.log(`StudyEdu running at http://localhost:${PORT}`);
});